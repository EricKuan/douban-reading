package com.fet.azure.myapplication;

import android.content.Context;
import android.util.Log;

import com.google.firebase.messaging.RemoteMessage;
import com.microsoft.windowsazure.messaging.notificationhubs.NotificationListener;

import java.util.Map;

public class Listener implements NotificationListener {
    private static final String TAG = "Listener";

    @Override
    public void onPushNotificationReceived(Context context, RemoteMessage remoteMessage) {
        /* The following notification properties are available. */
        RemoteMessage.Notification notification = remoteMessage.getNotification();
        String title = notification.getTitle();
        String body = notification.getBody();
        Map<String, String> data = remoteMessage.getData();

        if (remoteMessage != null) {
            Log.d(TAG, "Message Notification Title: " + title);
            Log.d(TAG, "Message Notification Body: " + remoteMessage);
        }

        if (data != null) {
            for (Map.Entry<String, String> entry : data.entrySet()) {
                Log.d(TAG, "key, " + entry.getKey() + " value " + entry.getValue());
            }
        }
    }

}
