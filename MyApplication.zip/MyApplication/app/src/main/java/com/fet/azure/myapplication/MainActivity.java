package com.fet.azure.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.microsoft.windowsazure.messaging.notificationhubs.NotificationHub;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        NotificationHub.setListener(new Listener());
        NotificationHub.start(this.getApplication(), "testNotifaction09549","Endpoint=sb://testnotifaction09449.servicebus.windows.net/;SharedAccessKeyName=DefaultFullSharedAccessSignature;SharedAccessKey=G4sJ6tmmuewsx87GsuNFmQilpmYHw+8ARYNCtO6VH7k=");
    }
}